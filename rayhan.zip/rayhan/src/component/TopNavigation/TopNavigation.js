import React, {Component, Fragment} from 'react';
import {Nav, Navbar, NavDropdown} from "react-bootstrap";
import whiteLogo from "../../images/whitelogo.svg";
import colorLogo from "../../images/colorlogo.svg";
import AllServicePage from "../../pagese/AllServicePage";
import AllcoursPage from "../../pagese/AllcoursPage";
import AllPortfolioPage from "../../pagese/AllPortfolioPage";
import ContactPage from "../../pagese/ContactPage";
import AboutPage from "../../pagese/AboutPage";
import {NavLink} from "react-router-dom";
class TopNavigation extends Component {

    constructor( props) {
        super();
        this.state={
           navBarTitle:"navTitle",
            variant:"dark",
            navbarLogo:[whiteLogo],
            navBack:"navbarBackground",
            navChang:"navItem",
            pageTitle:props.title
        }


    }

onscroll=()=>{
  if(window.scrollY >100){
      this.setState({variant:"light", navBarTitle:'navTitleScroll',navbarLogo:[colorLogo],navBack:"navbarBackgroundScroll",navChang:"navItemScroll"})
  }
  else if( window.scrollY<100){
      this.setState({ variant:"dark",navBarTitle:"navTitle",navbarLogo:[whiteLogo],navBack:"navbarBackground",navChang:"navItem"})
  }
}

componentDidMount() {
        window.addEventListener("scroll", this.onscroll)
}

    render() {
        return (
            <Fragment>
                <title>{this.state.pageTitle}</title>
                <Navbar className={this.state.navBack}fixed="top" collapseOnSelect expand="lg"  >
                    <Navbar.Brand > <NavLink className={this.state.navBarTitle} to="/"><img src={this.state.navbarLogo}/>  FREELANCER RAYHAN</NavLink> </Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="mr-auto">

                        </Nav>
                        <Nav>
                            <Nav.Link> <NavLink exact activeStyle={{color:'tomato'}}className={this.state.navChang} to="/">HOME</NavLink></Nav.Link>
                            <Nav.Link> <NavLink exact activeStyle={{color:'tomato'}} className={this.state.navChang} to="/services">SERVICES</NavLink></Nav.Link>
                            <Nav.Link> <NavLink exact activeStyle={{color:'tomato'}} className={this.state.navChang} to="/courses">COURSES</NavLink></Nav.Link>
                            <Nav.Link>  <NavLink  exact activeStyle={{color:'tomato'}}className={this.state.navChang} to ="/portfolio">PORTFOLIO</NavLink></Nav.Link>
                            <Nav.Link>  <NavLink exact activeStyle={{color:'tomato'}}className={this.state.navChang}  to ="/contact">CONTACT</NavLink></Nav.Link>
                            <Nav.Link>  <NavLink exact activeStyle={{color:'tomato'}} className={this.state.navChang} to="/about">ABOUT</NavLink></Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>

            </Fragment>
        );
    }
}

export default TopNavigation;