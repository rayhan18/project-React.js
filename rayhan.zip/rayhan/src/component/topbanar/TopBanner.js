import React, {Component, Fragment} from 'react';
import '../../assets/coustom.css';


import {Container,Row,Col,Button} from "react-bootstrap";

class TopBanner extends Component {
    render() {
        return (

            <Fragment>
            <Container fluid={true} className="topBanner p-0" >
            <div className="topBannerOverlay">
            <Container className="topContent">
            <Row>
            <Col className="text-center">
            <h1 className="topTitle animated infinite bounce delay-5s "> I AM SOFTWARE ENGINEER</h1>
        <h4 className="subTopTitle"> MOBILE AND WEB APPLICATION</h4>
        <Button variant="primary">MORE INFO</Button>
    </Col>

    </Row>

    </Container>
    </div>
    </Container>

    </Fragment>
        );
    }
}

export default TopBanner;