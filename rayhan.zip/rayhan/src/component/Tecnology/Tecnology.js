import React, {Component, Fragment} from 'react';
import {Container, Row,Col} from "react-bootstrap";
import {Bar, BarChart, ResponsiveContainer, Tooltip, XAxis} from "recharts";

class Tecnology extends Component {

    constructor() {
        super();
        this.state={
            data:[
                {Tecnology:"HTML", project: 95},
                {Tecnology:"CSS3", project: 86},
                {Tecnology:"BST ", project: 88},
                {Tecnology:"Js", project: 45},
                {Tecnology:"JQUERY", project: 86},
                {Tecnology:"REACT", project: 79},
                {Tecnology:"C PRO", project: 40}
            ]
        }
    }


    render(){
        const blue="rgba(0,130,230,0.8)"
        return (
            <Fragment>
                <Container>
                    <h2 className="text-center mt-5 mb-5">TECNOLOGY USE</h2>
                    <Row>
                        <Col style={{width:'100%',height:'300px'}} lg={6} md={12} sm={12}>
                            <ResponsiveContainer>
                            <BarChart width={100} height={300} data={this.state.data}>
                                <XAxis dataKey="Tecnology"/>
                                <Tooltip/>
                                <Bar dataKey="project" fill={blue}>

                                </Bar>
                            </BarChart>
                                </ResponsiveContainer>
                        </Col>

                        <Col lg={6} md={12} sm={12}>
                            <div>

                                <p className="text-justify">To build native android apps i use Java as well as kotline
                                    mainly. React JS is used for cross platform mobile application. I use MySQL database
                                    for relational database system. To build NoSQL application i use MongoDB. Firebase
                                    database system is used where it is necessary to provide realtime data flow
                                    facilities.</p>
                                    <p className="mt-1">
                                        I always build dynamic application. Admin panel is the heart of such kinds of
                                        application. I always try to provide sufficient features in admin panel to
                                        dominate application. According to client demand I use PHP OOP, CodeIgniter and
                                        Laravel to build admin panel section.
                                    </p>

                                    <p>
                                        Application security is a big deal for commercial application. I always ensure
                                        security portion of my application, moreover i build a security alert system, to
                                        notify admin when his system at risk
                                    </p>


                            </div>


                        </Col>

                    </Row>

                </Container>
            </Fragment>
        );
    }
}

export default Tecnology;

