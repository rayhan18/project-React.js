import React, {Component, Fragment} from 'react';
import {Col, Container, Row} from "react-bootstrap";
import desk from '../../images/desktop.svg'
import mob from '../../images/mobile.svg'
import gr from '../../images/grafic.svg'

class Services extends Component {

    render() {
        return (
            <Fragment>
                <Container>
                    <h2 className=" service mt-5 mb-5 text-center text-primary">MY SERVICE</h2>

                    <Row className="mt-3 text-center">
                        <Col lg={4} md={6} sm={12}>
                            <div className="desk">
                                <img className ="mt-3" src={desk}/>
                                <h2 className="mt-2 text-primary">Web Development</h2>
                                <p>I design and develop static and dynamic web sites as per your requirements as we believe, “web is world’s next home”.</p>
                            </div>
                        </Col>

                        <Col lg={4} md={6} sm={12}>
                        <div className="desk">
                            <img className ="mt-3" src={mob}/>
                            <h2 className="mt-2 text-primary">mobile Development</h2>
                            <p>I design and develop static and dynamic web sites as per your requirements as we believe, “web is world’s next home”.</p>
                        </div>
                    </Col>
                        <Col lg={4} md={6} sm={12}>
                            <div className="desk">
                                <img className = "mt-3" src={gr}/>
                                <h2 className="mt-2 text-primary">Graphics Design</h2>
                                <p>I design modern user interface and other graphical components for your business and instiution.</p>
                            </div>
                        </Col>
                    </Row>
                </Container>

            </Fragment>
        );
    }
}

export default Services;

