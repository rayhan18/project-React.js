import React, {Component, Fragment} from 'react';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import {Col, Container, Row} from "react-bootstrap";
import picture from "../../images/mobile.jpg";

class ClaintRivew extends Component {
    render() {
        var settings = {
            autoplaySpeed:4000,
            autoplay:true,
            dots: true,

            infinite: true,
            vertical: true,
            speed: 4000,
            slidesToShow: 1,
            slidesToScroll: 1,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        initialSlide: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        };



        return (
            <Fragment>
             <Container className="text-center">
                <h2 className="text-center text-primary mt-5 mb-5">Claint say</h2>
                     <Slider {...settings}>
                        <div>
                            <Row className="text-center">
                                <Col>
                                   <img className="claintSay" src={picture}/>
                                   <h2 className="mt-3"> WEB DEVELOPAR </h2>
                                    <p className="claintText"> First i analysis the requirement of project. According to the requirement i make a proper technical analysis, then i build a software architecture. According to the planning i start coding. Testing is also going on with coding. Final testing take place after finishing coding part. After successful implementation i provide 6 month free
                                        bug fixing service for corresponding project.</p>
                                </Col>
                            </Row>
                        </div>

                         <div>
                             <Row className="text-center">
                                 <Col>
                                     <img className="claintSay" src={picture}/>
                                     <h2 className="mt-3"> WEB DEVELOPAR </h2>
                                     <p className="claintText"> First i analysis the requirement of project. According to the requirement i make a proper technical analysis, then i build a software architecture. According to the planning i start coding. Testing is also going on with coding. Final testing take place after finishing coding part. After successful implementation i provide 6 month free
                                         bug fixing service for corresponding project.</p>
                                 </Col>
                             </Row>
                         </div>
                         <div>
                             <Row className="text-center">
                                 <Col>
                                     <img className="claintSay" src={picture}/>
                                     <h2 className="mt-3"> WEB DEVELOPAR </h2>
                                     <p className="claintText"> First i analysis the requirement of project. According to the requirement i make a proper technical analysis, then i build a software architecture. According to the planning i start coding. Testing is also going on with coding. Final testing take place after finishing coding part. After successful implementation i provide 6 month free
                                         bug fixing service for corresponding project.</p>
                                 </Col>
                             </Row>
                         </div>

                     </Slider>


             </Container>
            </Fragment>
        );
    }
}

export default ClaintRivew;