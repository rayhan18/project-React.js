import React, {Component, Fragment} from 'react';
import {Button, Col, Container, Form, Row} from "react-bootstrap";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faEnvelope, faMobile} from "@fortawesome/free-solid-svg-icons";

class AllContact extends Component {
    render() {
        return (
            <Fragment>
                <Container className="ContactPage">
                    <Row>
                        <Col lg={6} md={6} sm={12} className="ContactForm">
                            <Form>
                                <Form.Group controlId="formBasicEmail">
                                <Form.Label>NAME</Form.Label>
                                <Form.Control type="text" placeholder="YOUR NAME" />
                                </Form.Group>

                                <Form.Group controlId="formBasicEmail">
                                    <Form.Label>Email address</Form.Label>
                                    <Form.Control type="email" placeholder="Enter email" />
                                </Form.Group>

                                <Form.Group controlId="formBasicPassword">
                                    <Form.Label>Password</Form.Label>
                                    <Form.Control type="password" placeholder="Password" />
                                </Form.Group>

                                <Form.Group controlId="exampleForm.ControlTextarea1">
                                    <Form.Label> YOUR MESSAGE</Form.Label>
                                    <Form.Control as="textarea" rows="3" />
                                </Form.Group>

                                <Button variant="primary" type="submit">
                                    Submit
                                </Button>
                            </Form>
                        </Col>
                        <Col lg={6} md={6} sm={12} className="ContactPageAddrse">
                            <h3>Address</h3>
                            <p><FontAwesomeIcon  icon={faEnvelope} />  #79/6 Padma Residential </p>
                            <p> 3rd Floor Front Side, Rajshahi</p>
                            <p>Engr.Rabbil@yahoo.com</p>
                            <p><FontAwesomeIcon  icon={faMobile} /> +8801701063280</p>
                        </Col>
                    </Row>
                </Container>

            </Fragment>
        );
    }
}

export default AllContact;