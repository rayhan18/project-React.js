import React, {Component, Fragment} from 'react';
import {Button, Col, Container, Modal, Row} from "react-bootstrap";
import {BigPlayButton, Player} from "video-react";

class Sylebus extends Component {
    render() {
        return (
            <Fragment>
                <Container fluid={true} className="topBanner p-0" >
                    <div className="topBannerOverlay">
                        <Container className="topContent">
                            <Row>

                                <Col lg={6} md={6} sm={12}>
                                <h3 style={{color:'white'}}> SYLEBUS OF WEB DESIGN</h3>
                                <h5 style={{color:'tomato'}}> FROND END DEVELOPAR</h5>
                                <h5 style={{color:'tomato'}}> FULL STACK  DEVELOPAR</h5>
                                </Col>

                                <Col lg={6} md={6} sm={12}>
                                    <p style={{color:'white'}}>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap </p>
                                </Col>

                            </Row>

                        </Container>
                    </div>
                </Container>

                <Container style={{marginTop: '80px'}}>
                    <Row>

                        <Col sm={12} md={6} lg={6}>
                        <h2> list of program</h2>
                            <ul>
                                <li>Lorem Ipsum is simply dummy text of the printing</li>
                                <li>Lorem Ipsum is simply dummy text of the printing</li>
                                <li>Lorem Ipsum is simply dummy text of the printing</li>
                                <li>Lorem Ipsum is simply dummy text of the printing</li>
                                <li>Lorem Ipsum is simply dummy text of the printing</li>
                                <li>Lorem Ipsum is simply dummy text of the printing</li>
                                <li>Lorem Ipsum is simply dummy text of the printing</li>
                                <li>Lorem Ipsum is simply dummy text of the printing</li>
                                <li>Lorem Ipsum is simply dummy text of the printing</li>
                            </ul>
                            <Button variant="primary">BUY NOW </Button>
                        </Col>
                        <Col sm={12} md={6} lg={6}>
                            <Player style={{height:'200px'}}>
                                <source src="http://peach.themazzone.com/durian/movies/sintel-1024-surround.mp4" />
                                <BigPlayButton position="center"/>
                            </Player>
                        </Col>
                    </Row>
                </Container>
            </Fragment>
        );
    }
}

export default Sylebus;
