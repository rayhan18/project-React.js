import React, {Component, Fragment} from 'react';
import {Button, Card, Col, Container, Row} from "react-bootstrap";
import product from "../../images/mobilepondit.png";

class AllPortfolio extends Component {
    render() {
        return (
            <Fragment>
                <Container className="text-center">
                    <h2 className=" mt-5 mb-5 text-primary"> {this.props.PageTitle}</h2>
                    <Row className="mt-5">
                        <Col sm={12} md={6} lg={4}>
                            <div>
                                <Card style={{ width: '18rem' }}>
                                    <Card.Img variant="top" src={product} />
                                    <Card.Body>
                                        <Card.Title className="text-center">Card Title</Card.Title>
                                        <Card.Text>
                                            Some quick example text to build on the card title and make up the bulk of
                                            the card's content.
                                        </Card.Text>
                                        <Button  variant="primary">Go somewhere</Button>
                                    </Card.Body>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={12} md={6} lg={4}>
                            <div className="rightimage">
                                <Card style={{ width: '18rem' }}>
                                    <Card.Img variant="top" src={product} />
                                    <Card.Body>
                                        <Card.Title  className="text-center">Card Title</Card.Title>
                                        <Card.Text>
                                            Some quick example text to build on the card title and make up the bulk of
                                            the card's content.
                                        </Card.Text>
                                        <Button variant="primary">Go somewhere</Button>
                                    </Card.Body>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={12} md={6} lg={4}>
                            <div >
                                <Card style={{ width: '18rem' }}>
                                    <Card.Img variant="top" src={product} />
                                    <Card.Body>
                                        <Card.Title  className="text-center">Card Title</Card.Title>
                                        <Card.Text>
                                            Some quick example text to build on the card title and make up the bulk of
                                            the card's content.
                                        </Card.Text>
                                        <Button  className="" variant="primary">Go somewhere</Button>
                                    </Card.Body>
                                </Card>
                            </div>
                        </Col>
                    </Row>
                    </Container>
                <Container className="mt-5">
                <Row>
                        <Col sm={12} md={6} lg={4}>

                                <Card style={{ width: '18rem' }}>
                                    <Card.Img variant="top" src={product} />
                                    <Card.Body>
                                        <Card.Title  className="text-center">Card Title</Card.Title>
                                        <Card.Text>
                                            Some quick example text to build on the card title and make up the bulk of
                                            the card's content.
                                        </Card.Text>
                                        <Button  className="" variant="primary">Go somewhere</Button>
                                    </Card.Body>
                                </Card>

                        </Col>
                        <Col sm={12} md={6} lg={4}>
                            <div >
                                <Card style={{ width: '18rem' }}>
                                    <Card.Img variant="top" src={product} />
                                    <Card.Body>
                                        <Card.Title  className="text-center">Card Title</Card.Title>
                                        <Card.Text>
                                            Some quick example text to build on the card title and make up the bulk of
                                            the card's content.
                                        </Card.Text>
                                        <Button  className="" variant="primary">Go somewhere</Button>
                                    </Card.Body>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={12} md={6} lg={4}>
                            <div >
                                <Card style={{ width: '18rem' }}>
                                    <Card.Img variant="top" src={product} />
                                    <Card.Body>
                                        <Card.Title  className="text-center">Card Title</Card.Title>
                                        <Card.Text>
                                            Some quick example text to build on the card title and make up the bulk of
                                            the card's content.
                                        </Card.Text>
                                        <Button  className="" variant="primary">Go somewhere</Button>
                                    </Card.Body>
                                </Card>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </Fragment>
        );
    }
}

export default AllPortfolio;