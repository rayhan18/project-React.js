import React, {Component, Fragment} from 'react';
import {Card, Col, Container, Row} from "react-bootstrap";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import CountUp from 'react-countup';
import {faCheckCircle} from "@fortawesome/free-solid-svg-icons/faCheckCircle";
import VisibilitySensor from "react-visibility-sensor"
class ParlaxCover extends Component {

    render() {
        return (
            <Fragment>

                <Container fluid={true} className="paralaxCover p-0" >
                    <div className="paralaxCoverOverlay">
                        <Container className="text-center">
                            <Row>
                                <Col lg={8} md={4} sm={12}>
                                    <Row className="countSection">
                                       <Col >
                                           <h2 className="countNumber">

                                               <CountUp start={0} end={100}>
                                                   {({ countUpRef, start }) => (
                                                       <VisibilitySensor onChange={start} delayedCall={start}>
                                                           <span ref={countUpRef} />
                                                       </VisibilitySensor>
                                                   )}
                                               </CountUp>
                                           </h2>
                                           <h3 className="countTitle">TOTAL PROJECTS</h3>
                                           <hr className="bg-white w-25"/>
                                       </Col>
                                        <Col>
                                            <h2 className="countNumber">

                                                <CountUp start={0} end={100}>
                                                    {({ countUpRef, start }) => (
                                                        <VisibilitySensor onChange={start} delayedCall={start}>
                                                            <span ref={countUpRef} />
                                                        </VisibilitySensor>
                                                    )}
                                                </CountUp>
                                            </h2>
                                            <h3 className="countTitle">TOTAL PROJECTS</h3>
                                            <hr className="bg-white w-25"/>
                                        </Col>
                                    </Row>

                                </Col>

                                <Col lg={4} md={8} sm={12}>
                                    <Card className="cardTop" style={{ width: '15rem' }}>
                                        <Card.Body>
                                            <Card.Title  className="text-justify">Project Sempol</Card.Title>
                                            <p className="text-justify"><FontAwesomeIcon className="cardIcon" icon={faCheckCircle} /> This is Card Link</p>
                                            <p  className="text-justify"><FontAwesomeIcon className="cardIcon"icon={faCheckCircle} /> Card Link</p>
                                            <p  className="text-justify"><FontAwesomeIcon className="cardIcon" icon={faCheckCircle} /> Card Link</p>
                                            <p  className="text-justify"><FontAwesomeIcon className="cardIcon" icon={faCheckCircle} /> Card Link</p>


                                        </Card.Body>
                                    </Card>
                                </Col>
                            </Row>

                        </Container>
                    </div>
                </Container>

            </Fragment>
        );
    }
}

export default ParlaxCover;