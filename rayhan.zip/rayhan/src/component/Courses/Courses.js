import React, {Component, Fragment} from 'react';
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import courses1 from '../../images/cpbg.jpg'
import {Button} from "react-bootstrap";
import {Link} from "react-router-dom";
import Sylebus from "../Sylebas/Sylebus";


class Courses extends Component {
    render() {
        return (
            <Fragment>
                <Container>
                    <div>
                        <h2 className="mt-5 mb-5 text-center text-primary"> OUR COURSES</h2>
                        <Row>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                               <h4 className="text-danger">Web Development</h4>
                                <p>I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <Button><Link to="/Sylebus">details</Link> </Button>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col>
                                <h4 className="text-danger">Web Development</h4>
                                <p>I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <Button><Link to="/Sylebus">details</Link> </Button>
                            </Col>
                        </Row>
                    </div>
                </Container>

                <Container>
                    <div>

                        <Row>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p className="text-justify">I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <Button><Link to="/Sylebus">details</Link> </Button>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p className="text-justify">I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <Button><Link to="/Sylebus">details</Link> </Button>
                            </Col>
                        </Row>
                    </div>
                </Container>
            </Fragment>
        );
    }
}

export default Courses;