import React, {Component, Fragment} from 'react';
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import courses1 from "../../images/cpbg.jpg";

class AllCours extends Component {
    render() {
        return (
            <Fragment>
                <Container className="mt-5">
                    <div>

                        <Row>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p>I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <a href="#">details</a>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p>I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <a href="#">details</a>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p>I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <a href="#">details</a>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p>I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <a href="#">details</a>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p>I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <a href="#">details</a>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p>I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <a href="#">details</a>
                            </Col>
                        </Row>
                    </div>
                </Container>

                <Container>
                    <div>

                        <Row>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p className="text-justify">I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <a href="#">details</a>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <img className="cours_image" src={courses1}/>
                            </Col>
                            <Col lg={3} md={6} sm={12}>
                                <h4 className="text-danger">Web Development</h4>
                                <p className="text-justify">I build native and cross platfrom mobile app for your business app
                                    for your business</p>
                                <a href="#">details</a>
                            </Col>
                        </Row>
                    </div>
                </Container>
            </Fragment>
        );
    }
}

export default AllCours;