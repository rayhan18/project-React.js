export default class NavBar {

}