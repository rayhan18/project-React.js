import React, {Component, Fragment} from 'react';
import {Button, Col, Container, Row} from "react-bootstrap";
import product from'../../images/mobilepondit.png'
class ProjectDetails extends Component {
    render() {
        return (
            <Fragment>
                <Container className="mt-5">
                    <Row>
                        <Col lg={6}  md={6} sm={12}>
                            <img className="projectDetailsIMG" src={product}/>
                        </Col>
                        <Col lg={6}  md={6} sm={12}>
                            <h2>this is project details</h2>
                            <ul>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                                <li>Some quick example text to build</li>
                            </ul>
                            <Button>Go Live</Button>
                        </Col>

                    </Row>
                </Container>

            </Fragment>
        );
    }
}

export default ProjectDetails;