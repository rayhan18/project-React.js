import React, {Component, Fragment} from 'react';
import {Row,Col,Container} from "react-bootstrap";
import {faEnvelope, faMobile, faPlayCircle} from "@fortawesome/free-solid-svg-icons";
import {faFacebook,faYoutube} from "@fortawesome/free-brands-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {Link} from "react-router-dom";

class Footer extends Component {
    render() {
        return (
            <Fragment>
                <Container fluid={true} className=" footerText text-center ">
                   <Row className="mt-5">

                           <Col lg={3} md={6} sm={6} className="text-justify">
                             <h3>Follow Me</h3>
                              <a href="#"> <FontAwesomeIcon  icon={faFacebook} />  facebook</a><br/>
                              <a href="#"> <FontAwesomeIcon  icon={faYoutube} />  Youtube</a>
                           </Col>

                       <Col lg={3} md={6} sm={6} className="text-justify">
                               <h3>Address</h3>
                               <p><FontAwesomeIcon  icon={faEnvelope} />  #79/6 Padma Residential </p>
                                  <p> 3rd Floor Front Side, Rajshahi</p>
                               <p>Engr.Rabbil@yahoo.com</p>
                               <p><FontAwesomeIcon  icon={faMobile} /> +8801701063280</p>
                           </Col>


                           <Col lg={3} md={6} sm={6} className="text-justify">
                               <h3>Information</h3>
                               <a href="#">About me</a><br/>
                               <a href="#">contact me</a>
                           </Col>

                           <Col lg={3} md={6} sm={6} className="text-justify">
                               <h3>Legal</h3>
                              <Link to="Refund">Refund Policy </Link><br/>
                               <Link to="Trams">Terms And Condition</Link><br/>
                              <Link to="Privacy"> Privacy Policy</Link>
                           </Col>
                   </Row>

                </Container>
<p className="copyRight">COPY RIGHT BY DEVELOPAR 1.2020</p>
            </Fragment>
        );
    }
}

export default Footer;