import React, {Component, Fragment} from 'react';
import TopNavigation from "../component/TopNavigation/TopNavigation";
import PageTop from "../component/PageTop/PageTop";
import AboutContent from "../component/AboutContent/AboutContent";
import Footer from "../component/Footer/Footer";
import AllService from "../component/AllServices/AllService";

class AllServicePage extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation/>
                <PageTop PageTitle="SERVICES"/>
                <AllService/>
                <Footer/>

            </Fragment>
        );
    }
}

export default AllServicePage;