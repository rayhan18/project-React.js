import React, {Component, Fragment} from 'react';
import TopNavigation from "../component/TopNavigation/TopNavigation";
import PageTop from "../component/PageTop/PageTop";
import Refund from "../component/Refand/Refund";
import Footer from "../component/Footer/Footer";

class RefundPage extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
            <TopNavigation title="Refund"/>
            <PageTop PageTitle="REFUND"/>
            <Refund/>
            <Footer/>
            </Fragment>
        );
    }
}

export default RefundPage;