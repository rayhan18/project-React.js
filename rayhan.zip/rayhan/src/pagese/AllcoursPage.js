import React, {Component, Fragment} from 'react';
import TopNavigation from "../component/TopNavigation/TopNavigation";
import PageTop from "../component/PageTop/PageTop";
import AboutContent from "../component/AboutContent/AboutContent";
import Footer from "../component/Footer/Footer";
import AllCours from "../component/AllCours/AllCours";

class AllcoursPage extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation title="cours"/>
                <PageTop PageTitle="All COURSE"/>
                <AllCours/>
                <Footer/>


            </Fragment>
        );
    }
}

export default AllcoursPage;