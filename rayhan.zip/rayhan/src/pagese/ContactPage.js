import React, {Component, Fragment} from 'react';
import TopNavigation from "../component/TopNavigation/TopNavigation";
import PageTop from "../component/PageTop/PageTop";
import AboutContent from "../component/AboutContent/AboutContent";
import Footer from "../component/Footer/Footer";
import AllContact from "../component/AllContact/AllContact";

class ContactPage extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
    <TopNavigation title="contact"/>
    <PageTop PageTitle="CONTACT ME"/>
    <AllContact/>
    <Footer/>

</Fragment>
);
}
}

export default ContactPage;