import React, {Component, Fragment} from 'react';
import TopNavigation from "../component/TopNavigation/TopNavigation";
import PageTop from "../component/PageTop/PageTop";
import AllContact from "../component/AllContact/AllContact";
import Footer from "../component/Footer/Footer";
import ProjectDetails from "../component/ProjectDetails/ProjectDetails";

class ProjectDetailsPage extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation title="PROJECT DETAILS"/>
                <PageTop PageTitle="PROJECT DETAILS"/>
                <ProjectDetails/>
                <Footer/>

            </Fragment>
        );
    }
}

export default ProjectDetailsPage;