import React, {Component, Fragment} from 'react';
import TopNavigation from "../component/TopNavigation/TopNavigation";
import PageTop from "../component/PageTop/PageTop";
import AboutContent from "../component/AboutContent/AboutContent";
import Footer from "../component/Footer/Footer";

class AboutPage extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation title="about"/>
                <PageTop PageTitle="ABOUT ME"/>
                <AboutContent/>
                <Footer/>


            </Fragment>
        );
    }
}

export default AboutPage;