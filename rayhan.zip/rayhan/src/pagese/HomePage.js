import React, {Component, Fragment} from 'react';
import TopNavigation from "../component/TopNavigation/TopNavigation";
import TopBanner from "../component/topbanar/TopBanner";
import Services from "../component/services/Services";
import Tecnology from "../component/Tecnology/Tecnology";
import ParlaxCover from "../component/ParlaxCover/ParlaxCover";
import Product from "../component/Product/Product";
import Courses from "../component/Courses/Courses";
import HowDo from "../component/Howdo/Howdo";
import ClaintRivew from "../component/ClaintRivew/ClaintRivew";
import Footer from "../component/Footer/Footer";

class HomePage extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation title="Home"/>
                <TopBanner/>
                <Services/>
                <Tecnology/>
                <ParlaxCover/>
                <Product/>
                <Courses/>
                <HowDo/>
                <ClaintRivew/>
                <Footer/>
                
            </Fragment>
        );
    }
}

export default HomePage;