import React, {Component, Fragment} from 'react';

import  {Switch,Route} from 'react-router-dom';
import HomePage from "../pagese/HomePage";
import AllServicePage from "../pagese/AllServicePage";
import AllcoursPage from "../pagese/AllcoursPage";
import AllPortfolioPage from "../pagese/AllPortfolioPage";
import ContactPage from "../pagese/ContactPage";
import AboutPage from "../pagese/AboutPage";
import refundPage from "../pagese/refundPage";
import TramsPage from "../pagese/TramsPage";
import PrivacyPage from "../pagese/PrivacyPage";
import ProjectDetailsPage from "../pagese/ProjectDetailsPage";
import SylebusPage from "../pagese/SylebusPage";

class AppRoute extends Component {
    render() {
        return (
            <Fragment>
                <Switch>
                    <Route exact path="/" component={HomePage}/>
                    <Route exact path="/services" component={AllServicePage}/>
                    <Route exact path="/courses" component={AllcoursPage}/>
                    <Route exact path="/portfolio" component={AllPortfolioPage}/>
                    <Route exact path="/contact" component={ContactPage}/>
                    <Route exact path="/about" component={AboutPage}/>
                    <Route exact path="/Refund" component={refundPage}/>
                    <Route exact path="/Trams" component={TramsPage}/>
                    <Route exact path="/Privacy" component={PrivacyPage}/>
                    <Route exact path="/ProjectDetails" component={ProjectDetailsPage}/>
                    <Route exact path="/Sylebus" component={SylebusPage}/>
                </Switch>

            </Fragment>
        );
    }
}

export default AppRoute;